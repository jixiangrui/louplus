#!/usr/bin/env python3

import os,json
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)

app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root@localhost/shiyanlou'
db = SQLAlchemy(app)

class File(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(80))
    created_time = db.Column(db.DateTime)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'))
    category = db.relationship('Category', backref=db.backref('files',lazy='dynamic'))
    content = db.Column(db.Text)

    def __init__(self, title, category, content, created_time=None):
        self.title = title
        self.category = category
        self.content = content
        if created_time is None:
           created_time = datetime.utcnow()
        self.created_time = created_time

    def __repr__(self):
        return '<File %r>' % self.title

class Category(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    name = db.Column(db.String(80))

    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return '<Category %r>' % self.name
        
# 创建数据库和数据表 
db.create_all()

# 添加数据
java = Category('Java')
python = Category('Python')
file1 = File('Hello Java', java, 'File Content - Java is cool!')
file2 = File('Hello Python', python, 'File Content - Python is cool!')

db.session.add(java)
db.session.add(python)
db.session.add(file1)
db.session.add(file2)
#db.session.commit()

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

basedir='/home/shiyanlou/files/'
@app.route('/')
def index():
    reslist = {'titles':[]}
    '''
    filelist = []
    for root, dirs, files in os.walk(basedir):
        for newfile in files:
            if os.path.splitext(newfile)[1] == '.json':
                filelist.append(os.path.join(root, newfile))
    for filename in filelist:
        with open(filename, 'r') as file:
            newfile = json.loads(file.read())
        reslist['titles'].append(newfile['title']) 
    '''
    files = db.session.query(File).all()
    for newfile in files:
        dic = {}
        dic['title'] = newfile.title
        dic['file_id'] = newfile.id
        reslist['titles'].append(dic)
    #print(reslist['titles'])

    '''
    test = db.session.query(File).all()
    print(test)
    print(type(test))
    for tmp in test:
        print(tmp.id)
        print(tmp.title)
        print(tmp.created_time)
        print(tmp.content)
    '''
    return render_template('index.html', filelist = reslist)

'''
@app.route('/files/<filename>')
def file(filename):
    
    filename = basedir + filename + '.json'
    try:
        with open(filename, 'r') as file:
            newfile = json.loads(file.read())
    except Exception:
        return render_template('404.html'), 404
    return render_template('file.html', newfile = newfile)
'''

@app.route('/files/<file_id>')
def file(file_id):
    try:
        newfile = File.query.filter_by(id=file_id).first()
    except Exception:
        return render_template('404.html'), 404
    if newfile is None:
        return render_template('404.html'), 404
    return render_template('file.html', newfile = newfile)
    
