#!/usr/bin/env python3

import os,json
from flask import Flask, render_template

app = Flask(__name__)

app.config['TEMPLATES_AUTO_RELOAD'] = True

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

basedir='/home/shiyanlou/files/'
@app.route('/')
def index():
    filelist = []
    reslist = {'titles':[]}
    for root, dirs, files in os.walk(basedir):
        for newfile in files:
            if os.path.splitext(newfile)[1] == '.json':
                filelist.append(os.path.join(root, newfile))
    for filename in filelist:
        with open(filename, 'r') as file:
            newfile = json.loads(file.read())
        reslist['titles'].append(newfile['title'])            
    return render_template('index.html', filelist = reslist)


@app.route('/files/<filename>')
def file(filename):
    filename = basedir + filename + '.json'
    try:
        with open(filename, 'r') as file:
            newfile = json.loads(file.read())
    except Exception:
        return render_template('404.html'), 404
    return render_template('file.html', newfile = newfile)


