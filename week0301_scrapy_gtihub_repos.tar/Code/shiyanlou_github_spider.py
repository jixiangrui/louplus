#!/usr/bin/env python3

import scrapy

class ShiyanlouGithubSpider(scrapy.Spider):

    name = 'shiyanlou-github'

    def start_requests(self):
        # url tmplate
        url_tmpl = "https://github.com/shiyanlou?tab=repositories&page={}"

        urls = (url_tmpl.format(i) for i in range(1,5))

        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)


    def parse(self, response):
        print(response)
        for repos in response.xpath('//li[@itemprop="owns"]'):
            yield{
                "name":repos.xpath('.//div[@class="d-inline-block mb-1"]/h3/a/text()').re_first('\n\s*(.+)'),
                "update_time":repos.xpath('.//div[@class="f6 text-gray mt-2"]/relative-time/@datetime').extract_first(default="null")
            }
    

