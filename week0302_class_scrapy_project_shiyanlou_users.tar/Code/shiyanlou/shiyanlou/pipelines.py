# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

from sqlalchemy.orm import sessionmaker
from shiyanlou.models import Course, engine


class ShiyanlouPipeline(object):

    # when deal item, call the func
    def process_item(self, item, spider):
        # diffrent item with diffrent function
        if isinstance(item, CourseItem):
            self._process_course_item(item)
        else:
            self._process_user_item(item)

    def _process_course_item(self, item, spider):
        item['students'] = int(item['students'])
        # deal students less than 1000
        '''
        if item['students'] < 1000:
            raise DropItem('Course students less than 1000.')
        else:
            self.session.add(Course(**item))
        '''
        self.session.add(Course(**item))
        return item
    
    def _process_user_item(self, item):
        item['level'] = int(item['level'][1:])
        item['join-date'] = datetime.strptime(item['join-date'].split()[0], '%Y-%m-%d').date()
        item['learn_courses_num'] = int(item['learn_courses_num'])
        self.session.add(User(**item))

    # when start spider, call the func
    def open_spider(self, spider):
        # start spider, create database session 
        Session = sessionmaker(bind=engine)
        self.session = Session()

    # when close spider, call the func
    def close_spider(self, spider):
        # close spider, close session
        self.session.commit()
        self.session.close()
