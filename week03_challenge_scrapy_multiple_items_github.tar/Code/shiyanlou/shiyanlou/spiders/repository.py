# -*- coding: utf-8 -*-
import scrapy
from shiyanlou.items import RepositoryItem


class RepositorySpider(scrapy.Spider):
    name = 'repository'
    #allowed_domains = ['github.com']
    #start_urls = ['http://github.com/']

    @property
    def start_urls(self):
        url_tmpl = 'https://github.com/shiyanlou?tab=repositories&page={}'
        return (url_tmpl.format(i) for i in range(1,5))

    def parse(self, response):
        for repos in response.xpath('//li[@itemprop="owns"]'):
            item = RepositoryItem()
            item['name'] = repos.xpath('.//div[@class="d-inline-block mb-1"]/h3/a/text()').re_first('\n\s*(.+)')
            item['update_time'] = repos.xpath('.//div[@class="f6 text-gray mt-2"]/relative-time/@datetime').extract_first()
             
            repos_url = response.urljoin(repos.xpath('.//div[@class="d-inline-block mb-1"]/h3/a/@href').extract_first())
            request = scrapy.Request(repos_url, callback=self.parse_after)
            request.meta['item'] = item
            yield request

    def parse_after(self,response):
        item = response.meta['item']
        item['commits'] = response.xpath('(//span[@class="num text-emphasized"])[1]/text()').re_first('\n\s*(.+)\n\s*')
        item['branches'] = response.xpath('(//span[@class="num text-emphasized"])[2]/text()').re_first('\n\s*(.+)\n\s*')
        item['releases'] = response.xpath('(//span[@class="num text-emphasized"])[3]/text()').re_first('\n\s*(.+)\n\s*')
        yield item
